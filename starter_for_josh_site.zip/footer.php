<footer class="container-fluid text-center">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <a class="navbar-brand calibri" href="#"><span class="josh calibri white">JOSH</span> <span
                        class="orange calibri">WHITKIN</span></a>
            </div>
            <div class="col-md-6">
                <a class="t-and-c" href="#">TERMS AND CONDITIONS</a>
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</footer> <!-- container=fluid -->
<?php wp_footer(); ?>
</html>